from flask import Flask
app = Flask('yourapplication')

import yourapplication.views
